
public interface BaseCurrency {

	void setEuros(double i);
	double getEuros();
	
	void setDollars(double i);
	double getDollars();
	
	void setYuan(double i);
	double getYuan();
	
	void setPounds(double i);
	double getPounds();
}
