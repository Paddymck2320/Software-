package lab6;

public class ArrayValues {

}
